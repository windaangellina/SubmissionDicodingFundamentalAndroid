package com.example.appgithub.github.database.user_favorite

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.appgithub.github.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class UserFavoriteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository : UserFavoriteRepository

    init {
        val userFavoriteDao = AppDatabase.getAppDatabase(application).userFavoriteDao()
        repository = UserFavoriteRepository(userFavoriteDao)
    }

    fun addFavorite(userFavorite: UserFavorite){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addFavorite(userFavorite)
        }
    }

    fun deleteFavoriteByUsername(username: String){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteFavoriteByUsername(username)
        }
    }

    fun getFavorite(username: String) : LiveData<UserFavorite>{
        return repository.getFavorite(username)
    }

    fun getAllFavorites() : LiveData<List<UserFavorite>> {
        return repository.getAllFavorites()
    }
}