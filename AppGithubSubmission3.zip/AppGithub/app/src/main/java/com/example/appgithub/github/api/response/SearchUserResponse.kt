package com.example.appgithub.github.api.response

class SearchUserResponse {

    var items: List<Item>? = null

    override fun toString(): String {
        return "SearchResponse size : ${items?.size}"
    }
}


