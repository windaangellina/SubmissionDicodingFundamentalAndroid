@file:Suppress("EqualsBetweenInconvertibleTypes")

package com.example.appgithub.github.database.provider

import android.content.*
import android.database.Cursor
import android.net.Uri
import android.util.Log
import com.example.appgithub.github.database.AppDatabase

import com.example.appgithub.github.database.user_favorite.UserFavorite
import com.example.appgithub.github.database.user_favorite.UserFavoriteDao
import java.lang.IllegalArgumentException

/**
 * A {@link ContentProvider} based on a Room database.
 *
 * no need to implement a ContentProvider unless you want to expose the data
 * outside your process or your application already uses a ContentProvider.
 */
class UserFavoriteContentProvider : ContentProvider() {

    private var userFavoriteDao : UserFavoriteDao? = null

    companion object {
        /** Authority of this content provider */
        private const val AUTHORITY : String = "com.example.appgithub.github"

        /** match code for some items in the UserFavorite table */
        const val CODE_USERFAV_DIR = 1

        /** match code for an item in the UserFavorite table*/
        const val CODE_USERFAV_ITEM = 2

        val TAG: String = UserFavoriteContentProvider::class.java.name

        /** URI Matcher*/
        var MATCHER : UriMatcher = UriMatcher(UriMatcher.NO_MATCH)

        fun matcherInit(){
            MATCHER.addURI(AUTHORITY, UserFavorite.TABLE_NAME, CODE_USERFAV_DIR)
            MATCHER.addURI(AUTHORITY, "${UserFavorite.TABLE_NAME}/*", CODE_USERFAV_ITEM)
        }
    }

    init {
        matcherInit()
    }

    override fun onCreate(): Boolean {
        /** Implement this to initialize your content provider on startup. */
        userFavoriteDao = context?.let { AppDatabase.getAppDatabase(it).userFavoriteDao() }
        return true
    }

    override fun getType(uri: Uri): String? {
        return null
    }

    override fun query(
        uri: Uri, projection: Array<String>?, selection: String?,
        selectionArgs: Array<String>?, sortOrder: String?,
    ): Cursor? {
        /** Implement this to handle query requests from clients. */
        Log.d(TAG, "query")

        val code = MATCHER.match(uri)
        if (code == CODE_USERFAV_DIR || code == CODE_USERFAV_ITEM){
            // apabila context null, return null
            val context : Context = context ?: return null

            var cursor : Cursor? = null
            if (code == CODE_USERFAV_DIR){
                cursor = userFavoriteDao?.getAllUserFavoritesAsCursor()
            }
            cursor?.setNotificationUri(context.contentResolver, uri)
            return cursor
        }
        else{
            throw IllegalArgumentException("Unknown URI : $uri - code : $code")
        }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        /** Implement this to handle requests to insert a new row */
        Log.d(TAG, "insert")

        when(MATCHER.match(uri)){
            CODE_USERFAV_DIR -> {
                // apabila context null, return null
                val context : Context = context ?: return null

                val id : Long = userFavoriteDao!!.insertByContentProvider(UserFavorite.fromContentValues(values))

                if (!id.equals(0)){
                    context.contentResolver.notifyChange(uri, null)
                    return ContentUris.withAppendedId(uri, id)
                }
            }
            CODE_USERFAV_ITEM -> {
                throw IllegalArgumentException("Invalid URI : Insert failed $uri")
            }
            else -> {
                throw IllegalArgumentException("Unknown URI : $uri")
            }
        }
        return null
    }

    override fun update(
        uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<String>?,
    ): Int {
        /** Implement this to handle requests to update one or more rows. */
        Log.d(TAG, "update")

        when(MATCHER.match(uri)) {
            CODE_USERFAV_DIR -> {
                if (context != null){
                    val count = UserFavorite.fromContentValues(values).let {
                        userFavoriteDao!!.updateByContentProvider(it)
                    }

                    if (count != 0){
                        context!!.contentResolver.notifyChange(uri, null)
                        return count
                    }
                }
            }
            CODE_USERFAV_ITEM -> {
                throw IllegalArgumentException("Invalid URI:  cannot update")
            }
            else -> {
                throw IllegalArgumentException("Unknown URI: $uri")
            }
        }
        return 0
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        /** Implement this to handle requests to delete one or more rows */
        Log.d(TAG, "delete")

        when(MATCHER.match(uri)) {
            CODE_USERFAV_DIR -> {
                throw IllegalArgumentException("Invalid uri: cannot delete")
            }
            CODE_USERFAV_ITEM -> {
                if (context != null){
                    val count = userFavoriteDao!!.deleteByContentProvider(ContentUris.parseId(uri))
                    context!!.contentResolver.notifyChange(uri, null)
                    return count
                }
            }
            else -> {
                throw IllegalArgumentException("Unknown URI: $uri")
            }
        }
        return 0
    }
}