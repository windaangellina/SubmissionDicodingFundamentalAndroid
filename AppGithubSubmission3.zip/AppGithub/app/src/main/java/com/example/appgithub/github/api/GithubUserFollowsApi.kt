package com.example.appgithub.github.api

import com.example.appgithub.BuildConfig
import com.example.appgithub.github.api.response.FollowsResponseItem
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path

interface GithubUserFollowsApi {
    @GET("/users/{username}/followers")
    @Headers("Authorization: token ${BuildConfig.GITHUB_TOKEN}")
    fun getFollowersByUsername(
        @Path("username")username : String
    ) : Call<List<FollowsResponseItem>>


    @GET("/users/{username}/following")
    @Headers("Authorization: token ${BuildConfig.GITHUB_TOKEN}")
    fun getFollowingsByUsername(
        @Path("username")username : String
    ) : Call<List<FollowsResponseItem>>
}