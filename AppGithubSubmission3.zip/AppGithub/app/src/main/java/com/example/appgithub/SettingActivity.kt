package com.example.appgithub

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.appgithub.databinding.ActivitySettingBinding
import com.example.appgithub.github.helper.AlarmReceiver
import com.example.appgithub.github.preference.SettingModel
import com.example.appgithub.github.preference.UserPreference

class SettingActivity : AppCompatActivity() {
    private var binding : ActivitySettingBinding? = null
    private lateinit var alarmReceiver: AlarmReceiver
    private lateinit var userPreference: UserPreference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        // inisialisasi
        alarmReceiver = AlarmReceiver()
        userPreference = UserPreference(applicationContext)
        loadReminderPreferences()

        //events
        var stateReminder = userPreference.getPreferences().reminderIsOn
        binding!!.switchReminder.setOnClickListener {
            stateReminder = !stateReminder
            changePreferences(stateReminder)
        }

        binding!!.iconBack.setOnClickListener {
            backToListUser()
        }
    }

    private fun loadReminderPreferences(){
        val settingModel = userPreference.getPreferences()
        binding!!.switchReminder.isChecked = settingModel.reminderIsOn

        if (settingModel.reminderIsOn){
            setReminder()
            //makeToast("Reminder is on")
        }
        else{
            alarmReceiver.cancelAlarmManager(applicationContext)
            //makeToast("Reminder is off")
        }
    }

    private fun setReminder(){
        val repeatMessage = resources.getString(R.string.notificationMessage)
        alarmReceiver.setRepeatingAlarm(this, AlarmReceiver.TYPE_REPEATING, "09:00", repeatMessage)
    }

    private fun changePreferences(reminderIsOn : Boolean){
        val settingModel = SettingModel()
        settingModel.reminderIsOn = reminderIsOn

        userPreference.setPreferences(settingModel)
        loadReminderPreferences()
    }

    private fun backToListUser(){
        val intentBack = Intent(applicationContext, MainActivity::class.java)
        intentBack.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        startActivity(intentBack)
    }

    override fun onDestroy() {
        super.onDestroy()
        binding = null
    }
}