package com.example.appgithub

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.appgithub.github.adapter.RecyclerViewFavoriteAdapter
import com.example.appgithub.github.database.user_favorite.UserFavorite
import com.example.appgithub.github.database.user_favorite.UserFavoriteViewModel
import com.example.appgithub.databinding.ActivityListFavoriteUserBinding

class ListFavoriteUserActivity : AppCompatActivity() {
    private lateinit var binding : ActivityListFavoriteUserBinding

    // ViewModel
    private lateinit var mUserFavoriteModel : UserFavoriteViewModel

    // adapter
    private lateinit var recyclerViewFavoriteAdapter : RecyclerViewFavoriteAdapter

    // data from database
    private var listUserFavorite = ArrayList<UserFavorite>()

    companion object;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ViewBinding
        binding = ActivityListFavoriteUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ViewModel
        mUserFavoriteModel = ViewModelProvider
            .AndroidViewModelFactory(application)
            .create(UserFavoriteViewModel::class.java)

        //tampilan awal
        setUpVisibility(isLoading = false, isError = false)

        setComponentValue()
    }

    private fun backToListUser(){
        val intentBack = Intent(applicationContext, MainActivity::class.java)
        intentBack.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        startActivity(intentBack)
    }

    private fun setComponentValue(){
        setRecyclerList()
        setComponentEvents()

        // loadDataFavoriteUsers()
        loadDataFavoriteUsersLiveData()
    }

    private fun setComponentEvents(){
        binding.iconBack.setOnClickListener {
            backToListUser()
        }
    }

    private fun setRecyclerList(){
        val recyclerView : RecyclerView = binding.recyclerViewFavorites
        recyclerView.layoutManager = LinearLayoutManager(recyclerView.context)

        recyclerViewFavoriteAdapter = RecyclerViewFavoriteAdapter()
        recyclerView.adapter = recyclerViewFavoriteAdapter

        recyclerViewFavoriteAdapter.setOnItemClickCallback(object : RecyclerViewFavoriteAdapter.OnItemClickCallback{
            override fun onItemClickCallback(user: UserFavorite) {
                goToDetailUser(user)
            }
        })
    }

    private fun goToDetailUser(user : UserFavorite){
        val intentDetail = Intent(applicationContext, DetailUserActivity::class.java)
        intentDetail.putExtra(DetailUserActivity.EXTRA_USERNAME, user.username)
        startActivity(intentDetail)
    }

    private fun loadDataFavoriteUsersLiveData(){
        setUpVisibility(isLoading = true, isError = false)
        mUserFavoriteModel.getAllFavorites().observe(this, {
            listUserFavorite.clear()
            listUserFavorite.addAll(it)

            recyclerViewFavoriteAdapter.setListUserFavorites(listUserFavorite)

            setUpVisibility(isLoading = false, isError = false)
        })
    }

    private fun setUpVisibility(isLoading : Boolean, isError : Boolean){
        if (isLoading){
            // sedang proses search
            binding.progressBar.visibility = View.VISIBLE

            binding.imgSearchInformation.visibility = View.INVISIBLE
            binding.tvKeterangan.visibility = View.INVISIBLE

        }else{
            // sudah selesai / belum pernah search
            binding.progressBar.visibility = View.INVISIBLE

            // tampilkan keterangan search apabila sudah pernah melakukan pencarian
            if (listUserFavorite.size == 0){
                binding.imgSearchInformation.visibility = View.VISIBLE
                binding.tvKeterangan.visibility = View.VISIBLE

                if (!isError){
                    binding.imgSearchInformation.setImageResource(R.drawable.svg_empty)
                    binding.tvKeterangan.text = resources.getString(R.string.no_favorite)
                }
                else{
                    binding.imgSearchInformation.setImageResource(R.drawable.svg_error_umum)
                    binding.tvKeterangan.text = resources.getString(R.string.encountered_an_error)
                }
            }
        }
    }

}