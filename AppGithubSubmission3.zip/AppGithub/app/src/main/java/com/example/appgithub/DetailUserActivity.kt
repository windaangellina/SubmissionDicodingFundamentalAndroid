package com.example.appgithub

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.commitNow
import com.example.appgithub.databinding.ActivityDetailUserBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class DetailUserActivity : AppCompatActivity() {
    private lateinit var binding : ActivityDetailUserBinding

    // data
    private var username : String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //component binding
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (intent.hasExtra(EXTRA_USERNAME)){
            username = intent.getStringExtra(EXTRA_USERNAME)
            username?.let { setBottomNavigation(it) }
        }

        if (savedInstanceState == null){
            binding.navView.selectedItemId = R.id.bmenu_detail_user_about
        }
    }

    companion object{
        const val EXTRA_USERNAME = "username"
    }

    private fun setBottomNavigation(username : String){
        binding.navView.setOnNavigationItemSelectedListener(
            BottomNavigationView.OnNavigationItemSelectedListener { item ->
                val fragment: Fragment
                when (item.itemId) {
                    R.id.bmenu_detail_user_about-> {
                        fragment = DetailUserDataFragment.newInstance(username)

                        // replace fragment using KTX
                        supportFragmentManager.commitNow(allowStateLoss = true){
                            replace(R.id.fragmentContainerDetailUser, fragment)
                        }

                        return@OnNavigationItemSelectedListener true
                    }
                    R.id.bmenu_detail_user_followers-> {
                        fragment = DetailUserFollowsFragment.newInstance(username, true)

                        // replace fragment using KTX
                        supportFragmentManager.commitNow(allowStateLoss = true){
                            replace(R.id.fragmentContainerDetailUser, fragment)
                        }

                        return@OnNavigationItemSelectedListener true
                    }
                    R.id.bmenu_detail_user_followings-> {
                        fragment = DetailUserFollowsFragment.newInstance(username, false)

                        // replace fragment using KTX
                        supportFragmentManager.commitNow(allowStateLoss = true){
                            replace(R.id.fragmentContainerDetailUser, fragment)
                        }

                        return@OnNavigationItemSelectedListener true
                    }
                }
                false
            })
    }


}