package com.example.appgithub.github.preference

import android.content.Context

class UserPreference(context: Context) {
    companion object{
        private const val PREFS_NAME = "user_pref"
        private const val REMINDER_STATE = "reminder_state"
    }

    private val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun setPreferences(settingModel: SettingModel){
        // mulai proses edit preferences
        val editor = preferences.edit()
        editor.putBoolean(REMINDER_STATE, settingModel.reminderIsOn)

        // simpan perubahan preferences
        editor.apply()
    }

    fun getPreferences() : SettingModel{
        val model = SettingModel()
        model.reminderIsOn = preferences.getBoolean(REMINDER_STATE, false)

        return model
    }
}