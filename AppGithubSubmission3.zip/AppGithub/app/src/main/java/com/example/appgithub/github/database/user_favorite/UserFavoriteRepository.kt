package com.example.appgithub.github.database.user_favorite

import androidx.lifecycle.LiveData

class UserFavoriteRepository(private val userFavoriteDao: UserFavoriteDao) {
    fun getFavorite(username: String) : LiveData<UserFavorite> {
        return userFavoriteDao.getUserFavByUsername(username)
    }

    fun getAllFavorites() : LiveData<List<UserFavorite>> {
        return userFavoriteDao.getAllUserFav()
    }

    suspend fun addFavorite(userFavorite: UserFavorite){
        userFavoriteDao.insert(userFavorite)
    }

    suspend fun deleteFavoriteByUsername(username: String){
        userFavoriteDao.deleteByUsername(username)
    }
}