package com.example.appgithub.github.preference

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class SettingModel (
    var reminderIsOn : Boolean = false
) : Parcelable