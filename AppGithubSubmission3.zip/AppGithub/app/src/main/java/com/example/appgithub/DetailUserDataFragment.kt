package com.example.appgithub

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.appgithub.databinding.FragmentDetailUserDataBinding
import com.example.appgithub.github.api.RetrofitClient
import com.example.appgithub.github.api.response.DetailUserResponse
import com.example.appgithub.github.database.user_favorite.UserFavorite
import com.example.appgithub.github.database.user_favorite.UserFavoriteViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


private const val ARG_USERNAME = "arg_username"

class DetailUserDataFragment : Fragment() {
    private lateinit var binding : FragmentDetailUserDataBinding
    private var username : String? = null
    private var isInFavorite : Boolean = false

    // ViewModel
    private lateinit var mUserFavoriteModel : UserFavoriteViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            username = it.getString(ARG_USERNAME)
        }
    }

    companion object {
        fun newInstance(username: String): DetailUserDataFragment {
            val args = Bundle().apply {
                putString(ARG_USERNAME, username)
            }

            val fragment = DetailUserDataFragment()
            fragment.arguments = args
            return fragment
        }
    }

    private fun makeToast(pesan : String){
        Toast.makeText(requireContext(), pesan, Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View {
        // Inflate binding for this fragment
        binding = FragmentDetailUserDataBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ViewModel
        //mUserFavoriteModel = ViewModelProvider(this).get(UserFavoriteViewModel::class.java)
        mUserFavoriteModel = ViewModelProvider.AndroidViewModelFactory(requireActivity().application)
            .create(UserFavoriteViewModel::class.java)


        // status favorite user awal
        username?.let { setUpFavoriteStatus(it) }
        setFavoriteIcon(isInFavorite)

        // get detail user from api
        username?.let { getDetailUserResponsesRetrofit(it) }
    }

    private fun getDetailUserResponsesRetrofit(username: String){
        //loading ProgressBar
        binding.progressBar.visibility = View.VISIBLE

        RetrofitClient.instanceDetailUser.findUserDetailByUsername(username).enqueue(object :
                Callback<DetailUserResponse> {
            override fun onResponse(
                    call: Call<DetailUserResponse>,
                    response: Response<DetailUserResponse>,
            ) {
                if (response.isSuccessful) {
                    // Log.d("responseDetail", response.body().toString())
                    response.body().let {
                        if (it != null) {
                            setComponentValue(it)
                        }

                        // berhenti loading ProgressBar
                        binding.progressBar.visibility = View.INVISIBLE
                    }
                } else {
                    binding.progressBar.visibility = View.INVISIBLE
                }
            }

            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                Log.d("error", t.message.toString())
            }

        })
    }

    private fun setComponentValue(user: DetailUserResponse){
        binding.tvUsername.text = user.login
        binding.tvRepository.text = user.publicRepos.toString()
        binding.tvFollowers.text = user.followers.toString()
        binding.tvFollowing.text = user.following.toString()

        if (user.company == null) {
            binding.tvCompany.text = "-"
        }
        else{
            binding.tvCompany.text = user.company
        }

        if (user.location == null){
            binding.tvLocation.text = "-"
        }
        else{
            binding.tvLocation.text = user.location
        }

        if (user.name == null){
            binding.tvNama.text = "-"
        }
        else{
            binding.tvNama.text = user.name
        }

        Glide.with(requireContext())
            .load(user.avatarUrl)
            .apply(RequestOptions().override(80, 80))
            .dontAnimate()
            .into(binding.imgFotoUser)

        setComponentEvents(user)
    }

    private fun setComponentEvents(user : DetailUserResponse){
        //event listeners
        binding.buttonOpenGithub.setOnClickListener {
            openGithub(user)
        }

        binding.iconShare.setOnClickListener {
            shareUser(user)
        }

        binding.iconBack.setOnClickListener {
            backToListUser()
        }

        // change favorite
        setUpFavoriteStatus(user.login)
        binding.iconFavorite.setOnClickListener {
            changeStatusFavorite(user)
        }
    }

    private fun shareUser(user: DetailUserResponse){
        val urlGitHub = "https://github.com/" + user.login
        val shareBody = "Find ${user.name} on github now! \n $urlGitHub"

        val shareIntent = Intent()
        shareIntent.action = Intent.ACTION_SEND
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "GitHub @${user.login}")
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareBody)
        startActivity(Intent.createChooser(shareIntent, "Share GitHub profile using"))
    }

    private fun openGithub(user: DetailUserResponse){
        val urlGitHub : String = "https://github.com/" + user.login
        val i = Intent(Intent.ACTION_VIEW)
        i.data = Uri.parse(urlGitHub)
        startActivity(i)
    }

    private fun backToListUser(){
        val intentBack = Intent(requireContext(), MainActivity::class.java)
        intentBack.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        startActivity(intentBack)
    }

    private fun setUpFavoriteStatus(username: String){
        mUserFavoriteModel.getFavorite(username).observe(viewLifecycleOwner, {
            isInFavorite = it != null
            setFavoriteIcon(isInFavorite)
        })
    }

    private fun setFavoriteIcon(isInFavorite : Boolean){
        if (isInFavorite){
            binding.iconFavorite.setImageResource(R.drawable.ic_like_1_filled_white)
        }
        else{
            binding.iconFavorite.setImageResource(R.drawable.ic_like_1_outline)
        }
    }

    private fun changeStatusFavorite(userParam : DetailUserResponse){
        if (this.isInFavorite){
            deleteFavorite(userParam)
        }
        else{
            insertFavorite(userParam)
        }

        isInFavorite = !isInFavorite
        setFavoriteIcon(isInFavorite)
    }

    private fun insertFavorite(user: DetailUserResponse) {
        val userfavorite = UserFavorite(user.login, user.avatarUrl)
        mUserFavoriteModel.addFavorite(userfavorite)
        activity?.let { makeToast(it.getString(R.string.addedToFavorite)) }
    }

    private fun deleteFavorite(user : DetailUserResponse){
        mUserFavoriteModel.deleteFavoriteByUsername(user.login)
        activity?.let { makeToast(it.getString(R.string.removedFromFavorite)) }
    }


}