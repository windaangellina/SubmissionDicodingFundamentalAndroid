package com.example.appgithub.github.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.appgithub.R
import com.example.appgithub.github.database.user_favorite.UserFavorite
import com.example.appgithub.databinding.ItemLayoutUserSimpleBinding

class RecyclerViewFavoriteAdapter : RecyclerView.Adapter<RecyclerViewFavoriteAdapter.ViewHolder>() {
    private var listUserFavorite = ArrayList<UserFavorite>()
    private lateinit var binding : ItemLayoutUserSimpleBinding

    //untuk onItemClick
    private var onItemClickCallback : OnItemClickCallback? = null
    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback){
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): RecyclerViewFavoriteAdapter.ViewHolder {
        binding = ItemLayoutUserSimpleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerViewFavoriteAdapter.ViewHolder, position: Int) {
        holder.bind(listUserFavorite[position])
    }

    override fun getItemCount(): Int {
        return listUserFavorite.size
    }

    fun setListUserFavorites(list : List<UserFavorite>){
        listUserFavorite.clear()
        listUserFavorite.addAll(list)

        notifyDataSetChanged()
    }

    inner class ViewHolder(binding: ItemLayoutUserSimpleBinding) : RecyclerView.ViewHolder(binding.root) {
        private val imgFotoUser : ImageView = binding.imgFotoUser
        private val tvUsername : TextView = binding.tvUsername

        fun bind(userFavorite : UserFavorite){
            tvUsername.text = userFavorite.username

            Glide.with(itemView.context)
                .load(userFavorite.avatarUrl)
                .apply(RequestOptions().override(80, 80))
                .placeholder(R.drawable.app_github_octocat)
                .error(R.drawable.app_github_mark_120px) // will be displayed if the image cannot be loaded
                .dontAnimate()
                .into(imgFotoUser)

            //set onItemClick
            itemView.setOnClickListener {
                onItemClickCallback?.onItemClickCallback(userFavorite)
            }
        }
    }

    interface OnItemClickCallback{
        fun onItemClickCallback(user: UserFavorite)
    }
}