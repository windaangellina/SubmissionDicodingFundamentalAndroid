package com.example.appgithub.github.api

import com.example.appgithub.BuildConfig
import com.example.appgithub.github.api.response.DetailUserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path

interface GithubDetailUserApi {
    @GET("/users/{username}")
    @Headers("Authorization: token ${BuildConfig.GITHUB_TOKEN}")
    fun findUserDetailByUsername(
        @Path("username")username : String
    ) : Call<DetailUserResponse>

}