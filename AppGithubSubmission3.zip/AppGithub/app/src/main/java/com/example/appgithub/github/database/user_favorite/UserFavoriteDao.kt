package com.example.appgithub.github.database.user_favorite

import android.database.Cursor
import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface UserFavoriteDao {

    @Query("select * from user_favs where username=:pusername")
    fun getUserFavByUsername(pusername : String) : LiveData<UserFavorite>

    @Query("select * from user_favs")
    fun getAllUserFav() : LiveData<List<UserFavorite>>

    @Insert
    suspend fun insert(userFavorite: UserFavorite)

    @Query("delete from user_favs where username=:pusername")
    suspend fun deleteByUsername(pusername: String)

    /**
     * Content Provider
     * */
    @Query("select * from user_favs")
    fun getAllUserFavoritesAsCursor(): Cursor

    /** insert a userfav data into the table
     * @return row id for newly inserted data
     * */
    @Insert
    fun insertByContentProvider(userFavorite: UserFavorite?) : Long

    /**
     * Delete a userfav data by ID
     * @return A number of userfavs deleted
     */
    @Query("DELETE FROM user_favs WHERE id = :id")
    fun deleteByContentProvider(id : Long) : Int

    /**
     * Update the userfav
     * @return A number of userfavs updated
     */
    @Update
    fun updateByContentProvider(userFavorite: UserFavorite) : Int
}