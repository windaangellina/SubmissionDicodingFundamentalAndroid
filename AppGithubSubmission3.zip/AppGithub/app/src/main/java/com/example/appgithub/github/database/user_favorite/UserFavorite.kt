@file:Suppress("MemberVisibilityCanBePrivate")

package com.example.appgithub.github.database.user_favorite

import android.content.ContentValues
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = UserFavorite.TABLE_NAME)
class UserFavorite(){
    @PrimaryKey(autoGenerate = true)
    var id : Int = 0
    var username : String = ""
    @ColumnInfo(name = "avatar_url")
    var avatarUrl : String = ""

    constructor(username: String, avatarUrl : String) : this() {
        this.username = username
        this.avatarUrl = avatarUrl
    }

    companion object{
        // atur data nama table dan nama kolom
        const val TABLE_NAME = "user_favs"
        private const val USERFAV_ID = "id"
        const val USERFAV_USERNAME = "username"
        const val USERFAV_AVATARURL = "avatar_url"

        fun fromContentValues(contentValues: ContentValues?): UserFavorite {
            val userFavorite = UserFavorite()

            if (contentValues != null) {
                if (contentValues.containsKey(USERFAV_ID)){
                    userFavorite.id = contentValues.getAsInteger(USERFAV_ID)
                }
                if (contentValues.containsKey(USERFAV_USERNAME)){
                    userFavorite.username = contentValues.getAsString(USERFAV_USERNAME)
                }

                if (contentValues.containsKey(USERFAV_AVATARURL)){
                    userFavorite.avatarUrl = contentValues.getAsString(USERFAV_AVATARURL)
                }
            }

            return userFavorite
        }
    }
}