package com.example.appgithub.github.api

import com.example.appgithub.BuildConfig
import com.example.appgithub.github.api.response.SearchUserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface GithubSearchUserApi {
    // Function that makes the network request, blocking the current thread
    @GET("search/users")
    @Headers("Authorization: token ${BuildConfig.GITHUB_TOKEN}")
    fun getSearchResults(
        @Query("q") login : String
    ) : Call<SearchUserResponse>
}