package com.example.consumerapp.data.user_favorite

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.consumerapp.data.DatabaseContract
import com.example.consumerapp.data.MappingHelperUserfavorite

class UserFavoriteViewModel(application: Application) : AndroidViewModel(application) {

    private var listUserFavorite = MutableLiveData<ArrayList<UserFavorite>>()

    fun setUserFavorites(context: Context){
        val cursorUserFavorite = context.contentResolver.query(
            DatabaseContract.UserFavoriteColumns.CONTENT_URI,
            null,null, null, null
        )

        val convertedListOfUserFavorites = MappingHelperUserfavorite.mapCursorUserFavoriteToArrayList(
            cursorUserFavorite
        )

        listUserFavorite.postValue(convertedListOfUserFavorites)
    }

    fun getAllFavoriteUsers() : LiveData<ArrayList<UserFavorite>>{
        return listUserFavorite
    }
}