package com.example.consumerapp.data

import android.net.Uri
import android.provider.BaseColumns
import com.example.consumerapp.data.user_favorite.UserFavorite

object DatabaseContract {
    private const val AUTHORITY : String = "com.example.appgithub.github"
    private const val SCHEME = "content"

    internal class UserFavoriteColumns : BaseColumns {
        companion object{
            private const val TABLE_NAME = UserFavorite.TABLE_NAME
            const val USERFAV_ID = UserFavorite.USERFAV_ID
            const val USERFAV_USERNAME = UserFavorite.USERFAV_USERNAME
            const val USERFAV_AVATAR_URL = UserFavorite.USERFAV_AVATARURL

            val CONTENT_URI: Uri = Uri.Builder().scheme(SCHEME)
                .authority(AUTHORITY)
                .appendPath(TABLE_NAME)
                .build()
        }
    }
}