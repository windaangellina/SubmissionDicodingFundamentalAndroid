package com.example.consumerapp.data.user_favorite

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = UserFavorite.TABLE_NAME)
class UserFavorite(){
    @PrimaryKey(autoGenerate = true)
    var id : Int = 0
    var username : String = ""
    @ColumnInfo(name = "avatar_url")
    var avatarUrl : String = ""

    constructor(id: Int, username: String, avatarUrl: String) : this() {
        this.id = id
        this.username = username
        this.avatarUrl = avatarUrl
    }

    companion object{
        // atur data nama table dan nama kolom
        const val TABLE_NAME = "user_favs"
        const val USERFAV_ID = "id"
        const val USERFAV_USERNAME = "username"
        const val USERFAV_AVATARURL = "avatar_url"

    }
}