package com.example.consumerapp

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.consumerapp.adapter.RecyclerViewFavoriteAdapter
import com.example.consumerapp.data.user_favorite.UserFavorite
import com.example.consumerapp.data.user_favorite.UserFavoriteViewModel
import com.example.consumerapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding

    // ViewModel
    private lateinit var mUserFavoriteModel : UserFavoriteViewModel

    // adapter
    private lateinit var recyclerViewFavoriteAdapter : RecyclerViewFavoriteAdapter

    // data from database
    private var listUserFavorite = ArrayList<UserFavorite>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ViewModel
        mUserFavoriteModel = ViewModelProvider
            .AndroidViewModelFactory(application)
            .create(UserFavoriteViewModel::class.java)

        //tampilan awal
        setUpVisibility(false)

        setComponentValue()
    }

    private fun setComponentValue(){
        setRecyclerList()
        loadDataFavoriteUsers()
    }

    private fun setRecyclerList(){
        val recyclerView : RecyclerView = binding.recyclerViewFavorites
        recyclerView.layoutManager = LinearLayoutManager(recyclerView.context)

        recyclerViewFavoriteAdapter = RecyclerViewFavoriteAdapter(listUserFavorite)
        recyclerView.adapter = recyclerViewFavoriteAdapter
    }

    private fun loadDataFavoriteUsers() {
        setUpVisibility(true)

        mUserFavoriteModel.setUserFavorites(applicationContext)
        mUserFavoriteModel.getAllFavoriteUsers().observe(this, {
            if (it != null) {
                listUserFavorite.clear()
                listUserFavorite.addAll(it)

                recyclerViewFavoriteAdapter.notifyDataSetChanged()

                setUpVisibility(false)
            } else {
                Log.d("ConsumerApp", "tidak ada data")
            }
        })
    }

    private fun setUpVisibility(isLoading : Boolean){
        if (isLoading){
            // sedang proses search
            binding.progressBar.visibility = View.VISIBLE

            binding.imgKeteranganSearch.visibility = View.INVISIBLE
            binding.tvKeterangan.visibility = View.INVISIBLE

        }else{
            // sudah selesai / belum pernah search
            binding.progressBar.visibility = View.INVISIBLE

            // tampilkan keterangan search apabila sudah pernah melakukan pencarian
            if (listUserFavorite.size == 0){
                binding.imgKeteranganSearch.visibility = View.VISIBLE
                binding.tvKeterangan.visibility = View.VISIBLE

                binding.imgKeteranganSearch.setImageResource(R.drawable.svg_empty)
                binding.tvKeterangan.text = resources.getString(R.string.no_favorite)
            }
        }
    }

}



