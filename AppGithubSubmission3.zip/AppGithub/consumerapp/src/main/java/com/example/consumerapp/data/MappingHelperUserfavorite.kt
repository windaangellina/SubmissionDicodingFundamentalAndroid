package com.example.consumerapp.data

import android.database.Cursor
import com.example.consumerapp.data.user_favorite.UserFavorite

object MappingHelperUserfavorite {
    fun mapCursorUserFavoriteToArrayList(cursor: Cursor?) : ArrayList<UserFavorite> {
        val listUserFavorite = ArrayList<UserFavorite>()

        if (cursor != null){
            while (cursor.moveToNext()) {

                val id = cursor.getInt(cursor.getColumnIndexOrThrow(
                    DatabaseContract.UserFavoriteColumns.USERFAV_ID
                ))

                val username = cursor.getString(cursor.getColumnIndexOrThrow(
                    DatabaseContract.UserFavoriteColumns.USERFAV_USERNAME
                ))

                val avatarUrl = cursor.getString(cursor.getColumnIndexOrThrow(
                    DatabaseContract.UserFavoriteColumns.USERFAV_AVATAR_URL
                ))

                listUserFavorite.add(UserFavorite(id, username, avatarUrl))

            }
        }

        return listUserFavorite
    }
}